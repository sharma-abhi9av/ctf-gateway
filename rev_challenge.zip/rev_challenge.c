
#include <stdio.h>
const char flag[] = "P2P{reverse_me}";
int main() {
    printf("Welcome to the Rev challenge!\n");
    return 0;
}
